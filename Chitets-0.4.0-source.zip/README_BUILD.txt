CHITETS 0.4.0 - ONE CLICK APK BUILD

1. Extract the entire ZIP to a folder, or copy it over the existing Chitets project.
2. Keep the existing .build-tools folder if you already built an earlier version.
3. Double-click BUILD_APK.bat.
4. The first run may download portable JDK 17, Android SDK tools, and small CBR support JARs.
5. When successful, the APK is placed in dist\Chitets-0.4.0-debug.apk.

The builder includes:
- curl.exe download with retries and redirects, with BITS/.NET fallback;
- archive/JAR validation before reuse;
- automatic portable JDK 17 and Android SDK setup;
- non-ASCII project-path workaround through a temporary subst drive;
- persistent debug signing key in .build-tools;
- automatic Junrar 8.1.0 + SLF4J API download for CBR support;
- multi-dex packaging if D8 creates more than one classes*.dex file.

If the build fails, copy all text from the console window and send it back.
