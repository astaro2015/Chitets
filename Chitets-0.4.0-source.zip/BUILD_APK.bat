@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Chitets 0.4.0 APK Builder

echo ============================================================
echo              CHITETS 0.4.0 - APK BUILDER
echo ============================================================
echo.
echo One-click build. No Android Studio is required.
echo If Java or Android SDK is missing, the script will download
ECHO portable build tools into this project folder.
echo.

if not exist "%~dp0BUILD_APK.ps1" (
    echo [ERROR] BUILD_APK.ps1 was not found next to this BAT file.
    echo Extract the ENTIRE ZIP to one folder and run this BAT again.
    goto :fail
)

set "POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%POWERSHELL%" set "POWERSHELL=powershell.exe"

if not exist "%POWERSHELL%" (
    where powershell.exe >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Windows PowerShell was not found.
        goto :fail
    )
    set "POWERSHELL=powershell.exe"
)

echo Starting build...
echo.
"%POWERSHELL%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_APK.ps1"
set "RC=%ERRORLEVEL%"

echo.
if not "%RC%"=="0" goto :build_failed

set "APK=%~dp0dist\Chitets-0.4.0-debug.apk"
if not exist "%APK%" (
    echo [ERROR] Build returned success, but APK was not found:
    echo %APK%
    goto :fail
)

echo ============================================================
echo                         SUCCESS
echo ============================================================
echo.
echo APK created here:
echo %APK%
echo.
start "" explorer.exe /select,"%APK%"
echo The dist folder has been opened.
echo Copy the APK to the phone and install it.
echo.
pause
exit /b 0

:build_failed
echo ============================================================
echo                      BUILD FAILED
echo ============================================================
echo.
echo Exit code: %RC%
echo Copy ALL text from this window and send it to me.
echo.
pause
exit /b %RC%

:fail
echo.
echo Copy ALL text from this window and send it to me.
echo.
pause
exit /b 1
