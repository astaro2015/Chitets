$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$OriginalProjectDir = $ProjectDir
$ToolsDir = Join-Path $ProjectDir ".build-tools"
$DownloadsDir = Join-Path $ToolsDir "downloads"
$PortableJdkDir = Join-Path $ToolsDir "jdk17"
$PortableSdk = Join-Path $ToolsDir "android-sdk"
$DepsDir = Join-Path $ToolsDir "deps"
New-Item -ItemType Directory -Force $ToolsDir, $DownloadsDir, $DepsDir | Out-Null

function Test-DownloadedFile([string]$Path, [long]$MinBytes = 1024, [bool]$ExpectZip = $true) {
    if (-not (Test-Path $Path)) { return $false }
    try {
        if ((Get-Item $Path).Length -lt $MinBytes) { return $false }
    } catch { return $false }

    if ($ExpectZip) {
        try {
            Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
            $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
            $entryCount = $zip.Entries.Count
            $zip.Dispose()
            if ($entryCount -le 0) { return $false }
        } catch {
            return $false
        }
    }
    return $true
}

function Download-File([string[]]$Urls, [string]$OutFile, [long]$MinBytes = 1024, [bool]$ExpectZip = $true) {
    $outDir = Split-Path -Parent $OutFile
    if ($outDir) { New-Item -ItemType Directory -Force $outDir | Out-Null }

    if (Test-DownloadedFile $OutFile $MinBytes $ExpectZip) {
        Write-Host "[SETUP] Reusing existing verified download: $OutFile" -ForegroundColor Green
        return
    }

    $curlCommand = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curlCommand) {
        foreach ($downloadUrl in $Urls) {
            for ($attempt = 1; $attempt -le 2; $attempt++) {
                if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
                Write-Host "[SETUP] Downloading with curl (attempt $attempt): $downloadUrl" -ForegroundColor Yellow
                Write-Host "[SETUP] To: $OutFile" -ForegroundColor DarkGray
                & $curlCommand.Source --fail --location --retry 5 --retry-delay 2 --connect-timeout 30 --output $OutFile $downloadUrl
                $curlExit = $LASTEXITCODE
                if ($curlExit -eq 0 -and (Test-DownloadedFile $OutFile $MinBytes $ExpectZip)) {
                    Write-Host "[SETUP] Download OK." -ForegroundColor Green
                    return
                }
                Write-Host "[SETUP] curl did not complete successfully (exit $curlExit)." -ForegroundColor DarkYellow
            }
        }
    } else {
        Write-Host "[SETUP] curl.exe was not found; trying Windows download fallbacks." -ForegroundColor DarkYellow
    }

    $bitsCommand = Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue
    if ($bitsCommand) {
        foreach ($downloadUrl in $Urls) {
            try {
                if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
                Write-Host "[SETUP] Trying BITS: $downloadUrl" -ForegroundColor Yellow
                Start-BitsTransfer -Source $downloadUrl -Destination $OutFile -TransferType Download -ErrorAction Stop
                if (Test-DownloadedFile $OutFile $MinBytes $ExpectZip) {
                    Write-Host "[SETUP] Download OK (BITS)." -ForegroundColor Green
                    return
                }
            } catch {
                Write-Host "[SETUP] BITS failed: $($_.Exception.Message)" -ForegroundColor DarkYellow
            }
        }
    }

    foreach ($downloadUrl in $Urls) {
        try {
            if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
            Write-Host "[SETUP] Trying .NET WebClient: $downloadUrl" -ForegroundColor Yellow
            $webClient = New-Object System.Net.WebClient
            $webClient.Headers.Add("User-Agent", "Chitets-Builder/0.4.0")
            $webClient.DownloadFile($downloadUrl, $OutFile)
            $webClient.Dispose()
            if (Test-DownloadedFile $OutFile $MinBytes $ExpectZip) {
                Write-Host "[SETUP] Download OK (WebClient)." -ForegroundColor Green
                return
            }
        } catch {
            Write-Host "[SETUP] WebClient failed: $($_.Exception.Message)" -ForegroundColor DarkYellow
        }
    }

    if (Test-Path $OutFile) { Remove-Item -Force $OutFile -ErrorAction SilentlyContinue }
    throw "All download methods failed. Check Internet access, VPN/proxy/firewall, then run BUILD_APK.bat again."
}


function Test-PathNeedsAsciiAlias([string]$Path) {
    if (-not $Path) { return $false }
    return [System.Text.Encoding]::ASCII.GetString([System.Text.Encoding]::ASCII.GetBytes($Path)) -ne $Path
}

function New-AsciiProjectAlias([string]$TargetPath) {
    $substExe = Join-Path $env:SystemRoot "System32\subst.exe"
    if (-not (Test-Path $substExe)) { $substExe = "subst.exe" }

    foreach ($code in 90..68) {
        $letter = [char]$code
        $drive = "$letter`:"
        if (-not (Test-Path "$drive\")) {
            & $substExe $drive $TargetPath | Out-Null
            if ($LASTEXITCODE -eq 0 -and (Test-Path "$drive\")) {
                return $drive
            }
        }
    }
    throw "Could not create a temporary ASCII drive alias for the project path."
}

function Convert-ToAliasPath([string]$Path, [string]$OriginalRoot, [string]$AliasDrive) {
    if (-not $Path) { return $Path }
    if ($Path.Equals($OriginalRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        return "$AliasDrive\"
    }
    if ($Path.StartsWith($OriginalRoot + "\", [System.StringComparison]::OrdinalIgnoreCase)) {
        return $AliasDrive + $Path.Substring($OriginalRoot.Length)
    }
    return $Path
}

function Find-JavaHome {
    $homes = New-Object System.Collections.Generic.List[string]
    if ($env:JAVA_HOME) { $homes.Add($env:JAVA_HOME) }

    $javacCommand = Get-Command javac.exe -ErrorAction SilentlyContinue
    if ($javacCommand) {
        $homes.Add((Split-Path -Parent (Split-Path -Parent $javacCommand.Source)))
    }

    $commonRoots = @(
        (Join-Path $env:ProgramFiles "Eclipse Adoptium"),
        (Join-Path $env:ProgramFiles "Microsoft"),
        (Join-Path $env:ProgramFiles "Java"),
        (Join-Path $env:ProgramFiles "Android\Android Studio\jbr"),
        $PortableJdkDir
    ) | Where-Object { $_ -and (Test-Path $_) }

    foreach ($root in $commonRoots) {
        $found = Get-ChildItem $root -Filter javac.exe -File -Recurse -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($found) {
            $homes.Add((Split-Path -Parent (Split-Path -Parent $found.FullName)))
        }
    }

    foreach ($javaHomeCandidate in $homes | Select-Object -Unique) {
        if ($javaHomeCandidate -and (Test-Path (Join-Path $javaHomeCandidate "bin\javac.exe"))) {
            return $javaHomeCandidate
        }
    }
    return $null
}

function Ensure-Jdk17 {
    $detectedJavaHome = Find-JavaHome
    if ($detectedJavaHome) {
        $javaExe = Join-Path $detectedJavaHome "bin\java.exe"
        try {
            # java.exe prints its version to STDERR. Under Windows PowerShell 5,
            # redirecting native STDERR while ErrorActionPreference=Stop can create
            # a false terminating NativeCommandError, so temporarily allow it.
            $SavedErrorActionPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = "Continue"
                $versionText = (& $javaExe -version 2>&1 | Out-String)
                $JavaVersionExitCode = $LASTEXITCODE
            }
            finally {
                $ErrorActionPreference = $SavedErrorActionPreference
            }

            if ($JavaVersionExitCode -eq 0 -and $versionText -match 'version "(\d+)') {
                $major = [int]$Matches[1]
                if ($major -ge 17) {
                    Write-Host "[SETUP] Java found: $detectedJavaHome" -ForegroundColor Green
                    return $detectedJavaHome
                }
            }
        } catch {}
    }

    Write-Host "[SETUP] JDK 17 was not found. Downloading a portable JDK..." -ForegroundColor Yellow
    if (Test-Path $PortableJdkDir) { Remove-Item -Recurse -Force $PortableJdkDir }
    New-Item -ItemType Directory -Force $PortableJdkDir | Out-Null

    $jdkZip = Join-Path $DownloadsDir "jdk17.zip"
    $jdkUrls = @(
        "https://aka.ms/download-jdk/microsoft-jdk-17-windows-x64.zip",
        "https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse"
    )
    Download-File $jdkUrls $jdkZip 50000000 $true
    Expand-Archive -Path $jdkZip -DestinationPath $PortableJdkDir -Force

    $javac = Get-ChildItem $PortableJdkDir -Filter javac.exe -File -Recurse -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if (-not $javac) { throw "Portable JDK was downloaded, but javac.exe was not found." }

    $portableJavaHome = Split-Path -Parent (Split-Path -Parent $javac.FullName)
    Write-Host "[SETUP] Portable JDK ready: $portableJavaHome" -ForegroundColor Green
    return $portableJavaHome
}

function Test-SdkReady([string]$Root) {
    if (-not $Root -or -not (Test-Path $Root)) { return $false }
    $androidJar = Join-Path $Root "platforms\android-35\android.jar"
    $aapt2 = Join-Path $Root "build-tools\35.0.0\aapt2.exe"
    $d8 = Join-Path $Root "build-tools\35.0.0\d8.bat"
    $zipalign = Join-Path $Root "build-tools\35.0.0\zipalign.exe"
    $apksigner = Join-Path $Root "build-tools\35.0.0\apksigner.bat"
    return (Test-Path $androidJar) -and (Test-Path $aapt2) -and (Test-Path $d8) -and (Test-Path $zipalign) -and (Test-Path $apksigner)
}

function Find-SdkManager([string]$Root) {
    if (-not $Root -or -not (Test-Path $Root)) { return $null }
    $preferred = Join-Path $Root "cmdline-tools\latest\bin\sdkmanager.bat"
    if (Test-Path $preferred) { return $preferred }
    $found = Get-ChildItem $Root -Filter sdkmanager.bat -File -Recurse -ErrorAction SilentlyContinue |
        Select-Object -First 1
    if ($found) { return $found.FullName }
    return $null
}

function Ensure-CommandLineTools([string]$SdkRoot) {
    $sdkManager = Find-SdkManager $SdkRoot
    if ($sdkManager) { return $sdkManager }

    Write-Host "[SETUP] Android command-line tools were not found." -ForegroundColor Yellow
    Write-Host "[SETUP] Downloading official Google command-line tools..." -ForegroundColor Yellow

    New-Item -ItemType Directory -Force $SdkRoot | Out-Null
    $zipFile = Join-Path $DownloadsDir "android-commandline-tools.zip"
    $url = "https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip"
    $expectedSha256 = "90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a"
    Download-File @($url) $zipFile 50000000 $true

    $actualSha256 = (Get-FileHash $zipFile -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha256 -ne $expectedSha256) {
        throw "Android command-line tools SHA-256 mismatch. Expected $expectedSha256 but got $actualSha256"
    }

    $tmp = Join-Path $ToolsDir "cmdline-tools-extract"
    if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
    New-Item -ItemType Directory -Force $tmp | Out-Null
    Expand-Archive -Path $zipFile -DestinationPath $tmp -Force

    $source = Join-Path $tmp "cmdline-tools"
    if (-not (Test-Path $source)) { throw "Unexpected Android command-line tools ZIP layout." }

    $cmdRoot = Join-Path $SdkRoot "cmdline-tools"
    $latest = Join-Path $cmdRoot "latest"
    New-Item -ItemType Directory -Force $cmdRoot | Out-Null
    if (Test-Path $latest) { Remove-Item -Recurse -Force $latest }
    Move-Item -Path $source -Destination $latest
    Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue

    $sdkManager = Join-Path $latest "bin\sdkmanager.bat"
    if (-not (Test-Path $sdkManager)) { throw "sdkmanager.bat was not found after extraction." }
    return $sdkManager
}

function Ensure-AndroidSdk([string]$JavaHome) {
    $candidates = @(
        $env:ANDROID_SDK_ROOT,
        $env:ANDROID_HOME,
        (Join-Path $env:LOCALAPPDATA "Android\Sdk"),
        "C:\Android\Sdk",
        "D:\Android\Sdk",
        "E:\Android\Sdk",
        "F:\Android\Sdk",
        $PortableSdk
    ) | Where-Object { $_ } | Select-Object -Unique

    foreach ($candidate in $candidates) {
        if (Test-SdkReady $candidate) {
            Write-Host "[SETUP] Android SDK found: $candidate" -ForegroundColor Green
            return $candidate
        }
    }

    Write-Host "[SETUP] Complete Android SDK was not found." -ForegroundColor Yellow
    Write-Host "[SETUP] Creating a portable SDK inside the project..." -ForegroundColor Yellow
    $sdkRoot = $PortableSdk
    New-Item -ItemType Directory -Force $sdkRoot | Out-Null

    $env:JAVA_HOME = $JavaHome
    $env:PATH = (Join-Path $JavaHome "bin") + ";" + $env:PATH

    $sdkManager = Ensure-CommandLineTools $sdkRoot

    Write-Host "[SETUP] Accepting Android SDK licenses..." -ForegroundColor Yellow
    try {
        1..100 | ForEach-Object { "y" } | & $sdkManager "--sdk_root=$sdkRoot" --licenses | Out-Host
    } catch {
        Write-Host "[SETUP] License command returned an error; package installation will be attempted anyway." -ForegroundColor DarkYellow
    }

    Write-Host "[SETUP] Installing Android API 35 and Build Tools 35.0.0..." -ForegroundColor Yellow
    & $sdkManager "--sdk_root=$sdkRoot" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
    if ($LASTEXITCODE -ne 0) { throw "sdkmanager failed with exit code $LASTEXITCODE." }

    if (-not (Test-SdkReady $sdkRoot)) {
        throw "Android SDK installation finished, but required API 35/build-tools files are missing."
    }

    Write-Host "[SETUP] Portable Android SDK ready: $sdkRoot" -ForegroundColor Green
    return $sdkRoot
}

$JavaHome = Ensure-Jdk17
$env:JAVA_HOME = $JavaHome
$env:PATH = (Join-Path $JavaHome "bin") + ";" + $env:PATH

$SdkRoot = Ensure-AndroidSdk $JavaHome
$env:ANDROID_SDK_ROOT = $SdkRoot
$env:ANDROID_HOME = $SdkRoot

Write-Host "[SETUP] Checking comic archive dependencies..." -ForegroundColor Yellow
$JunrarDownload = Join-Path $DepsDir "junrar-8.1.0.jar"
$Slf4jDownload = Join-Path $DepsDir "slf4j-api-2.0.17.jar"
Download-File @(
    "https://repo.maven.apache.org/maven2/com/github/junrar/junrar/8.1.0/junrar-8.1.0.jar",
    "https://repo1.maven.org/maven2/com/github/junrar/junrar/8.1.0/junrar-8.1.0.jar"
) $JunrarDownload 200000 $true
Download-File @(
    "https://repo.maven.apache.org/maven2/org/slf4j/slf4j-api/2.0.17/slf4j-api-2.0.17.jar",
    "https://repo1.maven.org/maven2/org/slf4j/slf4j-api/2.0.17/slf4j-api-2.0.17.jar"
) $Slf4jDownload 50000 $true

$AsciiAliasDrive = $null
$SubstExe = Join-Path $env:SystemRoot "System32\subst.exe"
if (-not (Test-Path $SubstExe)) { $SubstExe = "subst.exe" }

try {
    # Some Windows Android build tools still mishandle non-ASCII paths.
    # If the project lives in a folder such as "Chitets" written in Cyrillic,
    # create a temporary drive-letter alias so native tools only see ASCII paths.
    if (Test-PathNeedsAsciiAlias $ProjectDir) {
        Write-Host "[SETUP] Non-ASCII characters detected in project path." -ForegroundColor Yellow
        $AsciiAliasDrive = New-AsciiProjectAlias $ProjectDir
        Write-Host "[SETUP] Temporary ASCII build alias: $AsciiAliasDrive\" -ForegroundColor Green

        $JavaHome = Convert-ToAliasPath $JavaHome $OriginalProjectDir $AsciiAliasDrive
        $SdkRoot = Convert-ToAliasPath $SdkRoot $OriginalProjectDir $AsciiAliasDrive
        $ProjectDir = "$AsciiAliasDrive\"

        $env:JAVA_HOME = $JavaHome
        $env:ANDROID_SDK_ROOT = $SdkRoot
        $env:ANDROID_HOME = $SdkRoot
        $env:PATH = (Join-Path $JavaHome "bin") + ";" + $env:PATH
    }

    $BuildTools = Join-Path $SdkRoot "build-tools\35.0.0"
    $AndroidJar = Join-Path $SdkRoot "platforms\android-35\android.jar"
    $Aapt2 = Join-Path $BuildTools "aapt2.exe"
    $D8 = Join-Path $BuildTools "d8.bat"
    $ZipAlign = Join-Path $BuildTools "zipalign.exe"
    $ApkSigner = Join-Path $BuildTools "apksigner.bat"
    $Javac = Join-Path $JavaHome "bin\javac.exe"
    $Jar = Join-Path $JavaHome "bin\jar.exe"
    $KeyTool = Join-Path $JavaHome "bin\keytool.exe"
    $JunrarJar = Join-Path $ProjectDir ".build-tools\deps\junrar-8.1.0.jar"
    $Slf4jJar = Join-Path $ProjectDir ".build-tools\deps\slf4j-api-2.0.17.jar"
    if (-not (Test-Path $JunrarJar) -or -not (Test-Path $Slf4jJar)) { throw "Comic dependency JARs are missing." }

    $BuildDir = Join-Path $ProjectDir "manual-build"
    $DistDir = Join-Path $ProjectDir "dist"
    if (Test-Path $BuildDir) { Remove-Item -Recurse -Force $BuildDir }
    $CompiledDir = Join-Path $BuildDir "compiled"
    $GenDir = Join-Path $BuildDir "gen"
    $ClassesDir = Join-Path $BuildDir "classes"
    $DexDir = Join-Path $BuildDir "dex"
    New-Item -ItemType Directory -Force $CompiledDir, $GenDir, $ClassesDir, $DexDir, $DistDir | Out-Null

    Write-Host ""
    Write-Host "[1/6] Compiling resources..." -ForegroundColor Cyan
    & $Aapt2 compile --dir (Join-Path $ProjectDir "app\src\main\res") -o $CompiledDir
    if ($LASTEXITCODE -ne 0) { throw "aapt2 compile failed." }

    $CompiledResources = @(Get-ChildItem $CompiledDir -Filter *.flat -File -Recurse | ForEach-Object { $_.FullName })
    if ($CompiledResources.Count -eq 0) { throw "aapt2 produced no compiled .flat resource files." }

    Write-Host "[2/6] Linking resources..." -ForegroundColor Cyan
    $ResourcesApk = Join-Path $BuildDir "resources.apk"
    $LinkArgs = @(
        "link",
        "-o", $ResourcesApk,
        "-I", $AndroidJar,
        "--manifest", (Join-Path $ProjectDir "app\src\main\AndroidManifest.xml"),
        "--java", $GenDir,
        "--min-sdk-version", "26",
        "--target-sdk-version", "35",
        "--version-code", "4",
        "--version-name", "0.4.0",
        "--auto-add-overlay"
    )
    foreach ($flatFile in $CompiledResources) {
        $LinkArgs += "-R"
        $LinkArgs += $flatFile
    }
    & $Aapt2 @LinkArgs
    if ($LASTEXITCODE -ne 0) { throw "aapt2 link failed." }

    Write-Host "[3/6] Compiling Java 17..." -ForegroundColor Cyan
    $SourceFiles = @(
        Get-ChildItem (Join-Path $ProjectDir "app\src\main\java") -Filter *.java -Recurse
        Get-ChildItem $GenDir -Filter *.java -Recurse
    ) | ForEach-Object { $_.FullName }

    if ($SourceFiles.Count -eq 0) { throw "No Java source files were found." }
    & $Javac -encoding UTF-8 -source 17 -target 17 -classpath "$AndroidJar;$JunrarJar;$Slf4jJar" -d $ClassesDir @SourceFiles
    if ($LASTEXITCODE -ne 0) { throw "javac failed." }

    $ClassesJar = Join-Path $BuildDir "classes.jar"
    & $Jar cf $ClassesJar -C $ClassesDir .
    if ($LASTEXITCODE -ne 0) { throw "Failed to create classes.jar." }

    Write-Host "[4/6] Creating classes.dex..." -ForegroundColor Cyan
    & $D8 --release --min-api 26 --lib $AndroidJar --output $DexDir $ClassesJar $JunrarJar $Slf4jJar
    if ($LASTEXITCODE -ne 0) { throw "D8 failed." }

    Write-Host "[5/6] Packaging APK..." -ForegroundColor Cyan
    $WithDex = Join-Path $BuildDir "with-dex.apk"
    Copy-Item $ResourcesApk $WithDex
    $DexFiles = @(Get-ChildItem $DexDir -Filter "classes*.dex" -File | Sort-Object Name)
    if ($DexFiles.Count -eq 0) { throw "D8 produced no dex files." }
    foreach ($dexFile in $DexFiles) {
        & $Jar uf $WithDex -C $DexDir $dexFile.Name
        if ($LASTEXITCODE -ne 0) { throw "Failed to add $($dexFile.Name) to APK." }
    }

    $Aligned = Join-Path $BuildDir "aligned.apk"
    & $ZipAlign -f 4 $WithDex $Aligned
    if ($LASTEXITCODE -ne 0) { throw "zipalign failed." }

    Write-Host "[6/6] Signing APK..." -ForegroundColor Cyan

    # Keep one persistent debug key for all future builds. This lets a newer
    # Chitets APK update an older one on the phone without uninstalling it.
    $KeyStore = Join-Path $ProjectDir ".build-tools\chitets-debug.keystore"
    if (-not (Test-Path $KeyStore)) {
        Write-Host "[SETUP] Creating persistent debug signing key..." -ForegroundColor Yellow

        # Windows PowerShell 5 can turn native STDERR into a terminating
        # NativeCommandError when ErrorActionPreference is Stop. keytool writes
        # its normal 'Generating RSA key pair...' status to STDERR, so allow
        # native output here and judge success only by the real process exit code.
        $SavedErrorActionPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = "Continue"
            & $KeyTool -genkeypair -keystore $KeyStore -storepass android -alias androiddebugkey `
                -keypass android -dname "CN=Android Debug,O=Chitets,C=RU" -keyalg RSA -keysize 2048 -validity 10000
            $KeyToolExitCode = $LASTEXITCODE
        }
        finally {
            $ErrorActionPreference = $SavedErrorActionPreference
        }

        if ($KeyToolExitCode -ne 0 -or -not (Test-Path $KeyStore)) {
            throw "keytool failed (exit $KeyToolExitCode)."
        }
        Write-Host "[SETUP] Debug signing key created." -ForegroundColor Green
    }
    else {
        Write-Host "[SETUP] Reusing persistent debug signing key." -ForegroundColor DarkGray
    }

    $Apk = Join-Path $DistDir "Chitets-0.4.0-debug.apk"
    if (Test-Path $Apk) { Remove-Item -Force $Apk }
    & $ApkSigner sign --ks $KeyStore --ks-key-alias androiddebugkey `
        --ks-pass pass:android --key-pass pass:android --out $Apk $Aligned
    if ($LASTEXITCODE -ne 0) { throw "apksigner failed." }

    & $ApkSigner verify --verbose $Apk
    if ($LASTEXITCODE -ne 0) { throw "APK signature verification failed." }

    $FinalApk = Join-Path $OriginalProjectDir "dist\Chitets-0.4.0-debug.apk"
    Write-Host ""
    Write-Host "DONE: $FinalApk" -ForegroundColor Green
    Write-Host "The APK is ready to copy to the phone." -ForegroundColor Green
}
finally {
    if ($AsciiAliasDrive) {
        & $SubstExe $AsciiAliasDrive /D | Out-Null
    }
}
