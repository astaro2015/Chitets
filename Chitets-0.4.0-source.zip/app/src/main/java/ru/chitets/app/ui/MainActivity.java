package ru.chitets.app.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import ru.chitets.app.model.Book;
import ru.chitets.app.store.BackupManager;
import ru.chitets.app.store.LibraryStore;
import ru.chitets.app.store.ReadingPrefs;

public final class MainActivity extends Activity {
    private static final int PICK_BOOKS = 1001;
    private static final int PICK_FOLDER = 1002;
    private static final int CREATE_BACKUP = 1003;
    private static final int OPEN_BACKUP = 1004;
    public static final String EXTRA_URI = "book_uri";
    public static final String EXTRA_TITLE = "book_title";
    public static final String EXTRA_FORMAT = "book_format";

    private LibraryStore store;
    private BookAdapter adapter;
    private TextView emptyView;
    private EditText searchView;
    private TextView sortView;
    private TextView continueView;
    private Book continueBook;
    private int sortMode;
    private final ExecutorService importExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.PAPER);
        getWindow().setNavigationBarColor(Ui.PAPER);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        store = new LibraryStore(this);
        sortMode = getSharedPreferences("library_ui_v2", MODE_PRIVATE).getInt("sort_mode", 0);
        setContentView(buildContent());
        handleViewIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleViewIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLibrary();
    }

    private View buildContent() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.PAPER);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 10));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.text(this, "Чтец", 30, Ui.INK);
        title.setTypeface(Typeface.SERIF, Typeface.BOLD);
        TextView subtitle = Ui.text(this, "Твоя библиотека без рекламы", 13, Ui.MUTED);
        titles.addView(title);
        titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView folder = Ui.action(this, "Папка", false);
        folder.setOnClickListener(v -> pickFolder());
        header.addView(folder);

        TextView add = Ui.action(this, "+ Файлы", true);
        add.setOnClickListener(v -> pickBooks());
        header.addView(add);

        TextView menu = Ui.action(this, "⋮", false);
        menu.setTextSize(22);
        menu.setContentDescription("Меню");
        menu.setOnClickListener(v -> showAppMenu());
        header.addView(menu, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 44)));

        searchView = new EditText(this);
        searchView.setSingleLine(true);
        searchView.setHint("Поиск по названию или автору");
        searchView.setHintTextColor(0xff958878);
        searchView.setTextColor(Ui.INK);
        searchView.setTextSize(15);
        searchView.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search, 0, 0, 0);
        searchView.setCompoundDrawablePadding(Ui.dp(this, 10));
        searchView.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        searchView.setBackground(Ui.roundRect(0xffeee5d7, 0xffded0bd, 18, Ui.dp(this, 1)));
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 48));
        searchParams.setMargins(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 7));
        root.addView(searchView, searchParams);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 7));
        continueView = Ui.action(this, "▶  Продолжить", false);
        continueView.setTextSize(13);
        continueView.setMaxLines(1);
        continueView.setOnClickListener(v -> { if (continueBook != null) openBook(continueBook); });
        controls.addView(continueView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        sortView = Ui.action(this, sortLabel(), false);
        sortView.setTextSize(13);
        sortView.setOnClickListener(v -> {
            sortMode = (sortMode + 1) % 4;
            getSharedPreferences("library_ui_v2", MODE_PRIVATE).edit().putInt("sort_mode", sortMode).apply();
            sortView.setText(sortLabel());
            refreshLibrary();
        });
        controls.addView(sortView);
        root.addView(controls, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), Ui.dp(this, 8));
        list.setClipToPadding(false);
        list.setBackgroundColor(Color.TRANSPARENT);
        adapter = new BookAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> openBook(adapter.getItem(position)));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            showBookMenu(adapter.getItem(position));
            return true;
        });
        content.addView(list, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        emptyView = Ui.text(this, "Здесь появится твоя библиотека\n\nНажми «Добавить» и выбери EPUB, FB2, FB2.ZIP, TXT, HTML, PDF, CBZ или CBR", 17, Ui.MUTED);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        emptyView.setPadding(Ui.dp(this, 36), Ui.dp(this, 24), Ui.dp(this, 36), Ui.dp(this, 24));
        content.addView(emptyView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        searchView.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshLibrary(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        refreshLibrary();
        return root;
    }

    private String sortLabel() {
        if (sortMode == 1) return "Сортировка: добавленные";
        if (sortMode == 2) return "Сортировка: А–Я";
        if (sortMode == 3) return "Сортировка: коллекции";
        return "Сортировка: недавние";
    }

    private void showAppMenu() {
        String[] items = {"Экспорт резервной копии", "Импорт резервной копии", "О Чтеце 0.4.0"};
        new AlertDialog.Builder(this)
                .setTitle("Чтец")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) createBackupFile();
                    else if (which == 1) chooseBackupFile();
                    else new AlertDialog.Builder(this)
                            .setTitle("Чтец 0.4.0")
                            .setMessage("EPUB • FB2 • TXT • HTML • PDF • CBZ • CBR\n\nБиблиотека, закладки, заметки, коллекции и резервные копии — локально на устройстве.")
                            .setPositiveButton("OK", null)
                            .show();
                }).show();
    }

    private void createBackupFile() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "Chitets-backup.json");
        startActivityForResult(intent, CREATE_BACKUP);
    }

    private void chooseBackupFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, OPEN_BACKUP);
    }

    private void writeBackup(Uri uri) {
        if (uri == null) return;
        importExecutor.execute(() -> {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new IllegalStateException("Не удалось создать файл");
                out.write(BackupManager.exportBackup(this).getBytes(StandardCharsets.UTF_8));
                runOnUiThread(() -> Toast.makeText(this, "Резервная копия сохранена", Toast.LENGTH_LONG).show());
            } catch (Exception error) {
                runOnUiThread(() -> new AlertDialog.Builder(this)
                        .setTitle("Не удалось сохранить копию")
                        .setMessage(error.getMessage())
                        .setPositiveButton("OK", null).show());
            }
        });
    }

    private void readBackup(Uri uri) {
        if (uri == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Восстановить резервную копию?")
                .setMessage("Текущая библиотека, прогресс, закладки, заметки и настройки будут заменены данными из копии. Сами файлы книг не копируются.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Восстановить", (dialog, which) -> importExecutor.execute(() -> {
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        if (in == null) throw new IllegalStateException("Не удалось открыть файл");
                        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                        byte[] chunk = new byte[16384];
                        int total = 0, read;
                        while ((read = in.read(chunk)) != -1) {
                            total += read;
                            if (total > 32 * 1024 * 1024) throw new IllegalStateException("Файл резервной копии слишком большой");
                            buffer.write(chunk, 0, read);
                        }
                        BackupManager.importBackup(this, new String(buffer.toByteArray(), StandardCharsets.UTF_8));
                        runOnUiThread(() -> {
                            sortMode = getSharedPreferences("library_ui_v2", MODE_PRIVATE).getInt("sort_mode", 0);
                            if (sortView != null) sortView.setText(sortLabel());
                            refreshLibrary();
                            Toast.makeText(this, "Резервная копия восстановлена", Toast.LENGTH_LONG).show();
                        });
                    } catch (Exception error) {
                        runOnUiThread(() -> new AlertDialog.Builder(this)
                                .setTitle("Не удалось восстановить копию")
                                .setMessage(error.getMessage())
                                .setPositiveButton("OK", null).show());
                    }
                })).show();
    }

    private void pickFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_FOLDER);
    }

    private void pickBooks() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/epub+zip", "application/x-fictionbook+xml", "application/pdf",
                "text/plain", "text/html", "application/zip", "application/vnd.comicbook+zip",
                "application/x-cbz", "application/vnd.comicbook-rar", "application/x-cbr",
                "application/x-rar-compressed", "application/vnd.rar", "application/octet-stream"
        });
        startActivityForResult(intent, PICK_BOOKS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == CREATE_BACKUP) {
            writeBackup(data.getData());
            return;
        }
        if (requestCode == OPEN_BACKUP) {
            readBackup(data.getData());
            return;
        }
        if (requestCode == PICK_FOLDER) {
            importFolder(data.getData(), data.getFlags());
            return;
        }
        if (requestCode != PICK_BOOKS) return;
        int count = 0;
        if (data.getData() != null) {
            importUri(data.getData(), data.getFlags());
            count++;
        }
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                importUri(clip.getItemAt(i).getUri(), data.getFlags());
                count++;
            }
        }
        refreshLibrary();
        Toast.makeText(this, count == 1 ? "Книга добавлена" : "Добавлено книг: " + count, Toast.LENGTH_SHORT).show();
    }

    private void importFolder(Uri treeUri, int flags) {
        if (treeUri == null) return;
        try {
            getContentResolver().takePersistableUriPermission(treeUri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        Toast.makeText(this, "Сканирую папку…", Toast.LENGTH_SHORT).show();
        importExecutor.execute(() -> {
            List<Uri> found = new ArrayList<>();
            try {
                String rootId = DocumentsContract.getTreeDocumentId(treeUri);
                collectDocuments(treeUri, rootId, found, 0);
            } catch (Exception ignored) {
            }
            int added = store.addMany(found);
            runOnUiThread(() -> {
                refreshLibrary();
                Toast.makeText(this, "Найдено: " + found.size() + ", добавлено: " + added, Toast.LENGTH_LONG).show();
            });
        });
    }

    private void collectDocuments(Uri treeUri, String parentId, List<Uri> out, int depth) {
        if (depth > 20 || out.size() >= 5000) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId);
        String[] projection = {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
        };
        try (Cursor cursor = getContentResolver().query(children, projection, null, null, null)) {
            if (cursor == null) return;
            while (cursor.moveToNext() && out.size() < 5000) {
                String id = cursor.getString(0);
                String name = cursor.getString(1);
                String mime = cursor.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    collectDocuments(treeUri, id, out, depth + 1);
                } else if (LibraryStore.isSupported(name, mime)) {
                    out.add(DocumentsContract.buildDocumentUriUsingTree(treeUri, id));
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void importUri(Uri uri, int flags) {
        if (uri == null) return;
        try {
            int takeFlags = flags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            getContentResolver().takePersistableUriPermission(uri, takeFlags);
        } catch (Exception ignored) {
        }
        store.add(uri);
    }

    private void handleViewIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction()) || intent.getData() == null) return;
        Uri uri = intent.getData();
        importUri(uri, intent.getFlags());
        Book book = store.add(uri);
        openBook(book);
    }

    private void openBook(Book book) {
        store.markOpened(book.uri);
        Class<?> activity;
        if ("PDF".equals(book.format)) activity = PdfActivity.class;
        else if ("CBZ".equals(book.format) || "CBR".equals(book.format)) activity = ComicActivity.class;
        else activity = ReaderActivity.class;
        Intent intent = new Intent(this, activity);
        intent.putExtra(EXTRA_URI, book.uri);
        intent.putExtra(EXTRA_TITLE, book.title);
        intent.putExtra(EXTRA_FORMAT, book.format);
        startActivity(intent);
    }

    private void showBookMenu(Book book) {
        String[] items = {"Открыть", "Коллекция…", "Убрать из библиотеки"};
        new AlertDialog.Builder(this)
                .setTitle(book.title)
                .setItems(items, (dialog, which) -> {
                    if (which == 0) openBook(book);
                    else if (which == 1) editCollection(book);
                    else confirmRemove(book);
                })
                .show();
    }

    private void editCollection(Book book) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Например: Фантастика");
        input.setText(book.collection == null ? "" : book.collection);
        int pad = Ui.dp(this, 20);
        FrameLayout holder = new FrameLayout(this);
        holder.setPadding(pad, 0, pad, 0);
        holder.addView(input, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Коллекция")
                .setMessage("Пустое поле уберёт книгу из коллекции.")
                .setView(holder)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (dialog, which) -> {
                    store.setCollection(book.uri, input.getText().toString());
                    refreshLibrary();
                })
                .show();
    }

    private void confirmRemove(Book book) {
        new AlertDialog.Builder(this)
                .setTitle("Убрать из библиотеки?")
                .setMessage(book.title + "\n\nСам файл останется на устройстве.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Убрать", (dialog, which) -> {
                    store.remove(book.uri);
                    refreshLibrary();
                }).show();
    }

    private void refreshLibrary() {
        if (adapter == null) return;
        List<Book> allBooks = store.getBooks();
        continueBook = null;
        for (Book book : allBooks) {
            float progress = ReadingPrefs.getProgress(this, book.uri);
            if (book.lastOpenedAt > 0 && progress > 0.001f && progress < 0.999f
                    && (continueBook == null || book.lastOpenedAt > continueBook.lastOpenedAt)) {
                continueBook = book;
            }
        }
        if (continueView != null) {
            continueView.setVisibility(continueBook == null ? View.INVISIBLE : View.VISIBLE);
            continueView.setText(continueBook == null ? "▶  Продолжить" : "▶  " + continueBook.title);
        }
        String query = searchView == null ? "" : searchView.getText().toString();
        adapter.setBooks(allBooks, query);
        emptyView.setVisibility(adapter.getCount() == 0 ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onDestroy() {
        importExecutor.shutdownNow();
        super.onDestroy();
    }

    private final class BookAdapter extends BaseAdapter {
        private final List<Book> books = new ArrayList<>();
        private final LruCache<String, Bitmap> coverCache = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
            @Override protected int sizeOf(String key, Bitmap value) {
                return value == null ? 0 : value.getByteCount();
            }
        };

        void setBooks(List<Book> source, String query) {
            books.clear();
            String needle = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
            for (Book book : source) {
                String haystack = (book.title + " " + book.author + " " + book.series + " " + book.collection + " " + book.fileName).toLowerCase(Locale.ROOT);
                if (needle.isEmpty() || haystack.contains(needle)) books.add(book);
            }
            if (sortMode == 0) {
                books.sort(Comparator.comparingLong((Book b) -> b.lastOpenedAt > 0 ? b.lastOpenedAt : b.addedAt).reversed());
            } else if (sortMode == 1) {
                books.sort(Comparator.comparingLong((Book b) -> b.addedAt).reversed());
            } else if (sortMode == 2) {
                books.sort(Comparator.comparing(b -> b.title.toLowerCase(Locale.ROOT)));
            } else {
                books.sort(Comparator
                        .comparing((Book b) -> b.collection == null || b.collection.isEmpty() ? "яяя" : b.collection.toLowerCase(Locale.ROOT))
                        .thenComparing(b -> b.title.toLowerCase(Locale.ROOT)));
            }
            notifyDataSetChanged();
        }

        @Override public int getCount() { return books.size(); }
        @Override public Book getItem(int position) { return books.get(position); }
        @Override public long getItemId(int position) { return books.get(position).uri.hashCode(); }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder holder;
            if (convertView == null) {
                convertView = createRow();
                holder = (Holder) convertView.getTag();
            } else {
                holder = (Holder) convertView.getTag();
            }
            bind(holder, getItem(position));
            return convertView;
        }

        private View createRow() {
            LinearLayout wrapper = new LinearLayout(MainActivity.this);
            wrapper.setPadding(Ui.dp(MainActivity.this, 6), Ui.dp(MainActivity.this, 5), Ui.dp(MainActivity.this, 6), Ui.dp(MainActivity.this, 5));
            wrapper.setLayoutParams(new android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            LinearLayout card = new LinearLayout(MainActivity.this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(Ui.dp(MainActivity.this, 12), Ui.dp(MainActivity.this, 12), Ui.dp(MainActivity.this, 12), Ui.dp(MainActivity.this, 12));
            card.setBackground(Ui.roundRect(0xfffffaf1, 0xffe6dac7, 18, Ui.dp(MainActivity.this, 1)));
            wrapper.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            FrameLayout coverFrame = new FrameLayout(MainActivity.this);
            TextView letters = Ui.text(MainActivity.this, "Ч", 20, Ui.WHITE);
            letters.setTypeface(Typeface.SERIF, Typeface.BOLD);
            letters.setGravity(Gravity.CENTER);
            coverFrame.addView(letters, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            ImageView coverImage = new ImageView(MainActivity.this);
            coverImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
            coverImage.setVisibility(View.GONE);
            coverFrame.addView(coverImage, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            card.addView(coverFrame, new LinearLayout.LayoutParams(Ui.dp(MainActivity.this, 58), Ui.dp(MainActivity.this, 82)));

            LinearLayout info = new LinearLayout(MainActivity.this);
            info.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams infoParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            infoParams.setMargins(Ui.dp(MainActivity.this, 14), 0, Ui.dp(MainActivity.this, 8), 0);
            card.addView(info, infoParams);

            TextView title = Ui.text(MainActivity.this, "", 18, Ui.INK);
            title.setTypeface(Typeface.SERIF, Typeface.BOLD);
            title.setMaxLines(2);
            info.addView(title);
            TextView author = Ui.text(MainActivity.this, "", 14, Ui.MUTED);
            author.setMaxLines(1);
            info.addView(author);
            TextView detail = Ui.text(MainActivity.this, "", 12, Ui.MUTED);
            detail.setPadding(0, Ui.dp(MainActivity.this, 7), 0, 0);
            info.addView(detail);
            TextView opened = Ui.text(MainActivity.this, "", 11, Ui.MUTED);
            opened.setPadding(0, Ui.dp(MainActivity.this, 2), 0, 0);
            info.addView(opened);

            TextView arrow = Ui.text(MainActivity.this, "›", 32, Ui.ACCENT);
            arrow.setGravity(Gravity.CENTER);
            card.addView(arrow, new LinearLayout.LayoutParams(Ui.dp(MainActivity.this, 28), Ui.dp(MainActivity.this, 48)));

            Holder holder = new Holder();
            holder.letters = letters;
            holder.coverImage = coverImage;
            holder.title = title;
            holder.author = author;
            holder.detail = detail;
            holder.opened = opened;
            wrapper.setTag(holder);
            return wrapper;
        }

        private void bind(Holder holder, Book book) {
            holder.title.setText(book.title);
            holder.author.setText(book.author);
            holder.author.setVisibility(book.author.isEmpty() ? View.GONE : View.VISIBLE);
            float progress = ReadingPrefs.getProgress(MainActivity.this, book.uri);
            String status = progress > 0.001f ? Math.round(progress * 100f) + "% прочитано" : "Не начато";
            StringBuilder detailText = new StringBuilder(book.format).append("  •  ").append(status);
            if (book.series != null && !book.series.isEmpty()) detailText.append("  •  ").append(book.series);
            if (book.collection != null && !book.collection.isEmpty()) detailText.append("  •  [").append(book.collection).append("]");
            holder.detail.setText(detailText.toString());
            if (book.lastOpenedAt > 0) {
                holder.opened.setText("Открывалась: " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(book.lastOpenedAt)));
                holder.opened.setVisibility(View.VISIBLE);
            } else {
                holder.opened.setVisibility(View.GONE);
            }

            holder.coverImage.setImageDrawable(null);
            Bitmap cover = decodeCover(book.coverPath, Ui.dp(MainActivity.this, 116), Ui.dp(MainActivity.this, 164));
            if (cover != null) {
                holder.coverImage.setImageBitmap(cover);
                holder.coverImage.setVisibility(View.VISIBLE);
            } else {
                holder.coverImage.setVisibility(View.GONE);
                holder.letters.setText(coverLetters(book));
                GradientDrawable background = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{colorFor(book.title), 0xff6d3525});
                background.setCornerRadius(Ui.dp(MainActivity.this, 9));
                holder.letters.setBackground(background);
            }
        }

        private Bitmap decodeCover(String uriText, int reqW, int reqH) {
            if (uriText == null || uriText.isEmpty()) return null;
            Bitmap cached = coverCache.get(uriText);
            if (cached != null && !cached.isRecycled()) return cached;
            try {
                Uri uri = Uri.parse(uriText);
                if (!"file".equalsIgnoreCase(uri.getScheme())) return null;
                File file = new File(uri.getPath());
                if (!file.isFile()) return null;
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
                int sample = 1;
                while (bounds.outWidth / sample > reqW * 2 || bounds.outHeight / sample > reqH * 2) sample *= 2;
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = Math.max(1, sample);
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
                if (bitmap != null) coverCache.put(uriText, bitmap);
                return bitmap;
            } catch (Exception ignored) {
                return null;
            }
        }

        private String coverLetters(Book book) {
            String text = book.title.trim();
            if (text.isEmpty()) return "Ч";
            String[] words = text.split("\\s+");
            String first = words[0].substring(0, 1);
            if (words.length > 1 && !words[1].isEmpty()) first += words[1].substring(0, 1);
            return first.toUpperCase(Locale.ROOT);
        }

        private int colorFor(String value) {
            int[] colors = {0xff9c4f2e, 0xff4e6b5a, 0xff5a567a, 0xff87612e, 0xff3f6575};
            return colors[Math.abs(value.hashCode()) % colors.length];
        }
    }

    private static final class Holder {
        TextView letters;
        ImageView coverImage;
        TextView title;
        TextView author;
        TextView detail;
        TextView opened;
    }
}
