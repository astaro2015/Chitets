package ru.chitets.app.store;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Map;
import java.util.Set;

public final class BackupManager {
    private static final int FORMAT_VERSION = 1;
    private static final String[] PREF_NAMES = {"library_v1", "reading_state_v1", "library_ui_v2", "pdf_ui_v2", "comic_ui_v1"};

    private BackupManager() {}

    public static String exportBackup(Context context) throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "chitets-backup");
        root.put("version", FORMAT_VERSION);
        root.put("appVersion", "0.4.0");
        root.put("exportedAt", System.currentTimeMillis());
        JSONObject prefs = new JSONObject();
        for (String name : PREF_NAMES) {
            prefs.put(name, exportPrefs(context.getSharedPreferences(name, Context.MODE_PRIVATE)));
        }
        root.put("preferences", prefs);
        return root.toString(2);
    }

    public static void importBackup(Context context, String raw) throws Exception {
        JSONObject root = new JSONObject(raw == null ? "" : raw);
        if (!"chitets-backup".equals(root.optString("format"))) {
            throw new IllegalArgumentException("Это не резервная копия Чтеца");
        }
        int version = root.optInt("version", 0);
        if (version <= 0 || version > FORMAT_VERSION) {
            throw new IllegalArgumentException("Неподдерживаемая версия резервной копии: " + version);
        }
        JSONObject prefs = root.optJSONObject("preferences");
        if (prefs == null) throw new IllegalArgumentException("В резервной копии нет данных");
        for (String name : PREF_NAMES) {
            JSONObject values = prefs.optJSONObject(name);
            if (values != null) importPrefs(context.getSharedPreferences(name, Context.MODE_PRIVATE), values);
        }
    }

    private static JSONObject exportPrefs(SharedPreferences prefs) throws Exception {
        JSONObject out = new JSONObject();
        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            Object value = entry.getValue();
            JSONObject item = new JSONObject();
            if (value instanceof String) {
                item.put("type", "string");
                item.put("value", value);
            } else if (value instanceof Integer) {
                item.put("type", "int");
                item.put("value", value);
            } else if (value instanceof Long) {
                item.put("type", "long");
                item.put("value", value);
            } else if (value instanceof Float) {
                item.put("type", "float");
                item.put("value", ((Float) value).doubleValue());
            } else if (value instanceof Boolean) {
                item.put("type", "boolean");
                item.put("value", value);
            } else if (value instanceof Set) {
                item.put("type", "strings");
                JSONArray array = new JSONArray();
                for (Object part : (Set<?>) value) array.put(String.valueOf(part));
                item.put("value", array);
            } else {
                continue;
            }
            out.put(entry.getKey(), item);
        }
        return out;
    }

    private static void importPrefs(SharedPreferences prefs, JSONObject values) throws Exception {
        SharedPreferences.Editor editor = prefs.edit().clear();
        JSONArray names = values.names();
        if (names != null) {
            for (int i = 0; i < names.length(); i++) {
                String key = names.getString(i);
                JSONObject item = values.optJSONObject(key);
                if (item == null) continue;
                String type = item.optString("type");
                switch (type) {
                    case "string": editor.putString(key, item.optString("value", "")); break;
                    case "int": editor.putInt(key, item.optInt("value")); break;
                    case "long": editor.putLong(key, item.optLong("value")); break;
                    case "float": editor.putFloat(key, (float) item.optDouble("value")); break;
                    case "boolean": editor.putBoolean(key, item.optBoolean("value")); break;
                    case "strings": {
                        JSONArray array = item.optJSONArray("value");
                        java.util.HashSet<String> set = new java.util.HashSet<>();
                        if (array != null) for (int j = 0; j < array.length(); j++) set.add(array.optString(j));
                        editor.putStringSet(key, set);
                        break;
                    }
                    default: break;
                }
            }
        }
        if (!editor.commit()) throw new IllegalStateException("Не удалось восстановить настройки");
    }
}
