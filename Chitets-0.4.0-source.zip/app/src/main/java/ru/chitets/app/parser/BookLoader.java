package ru.chitets.app.parser;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import ru.chitets.app.model.ReaderDocument;
import ru.chitets.app.store.LibraryStore;

public final class BookLoader {
    private BookLoader() {}

    public static ReaderDocument load(Context context, Uri uri) throws Exception {
        String fileName = resolveName(context, uri);
        String mime = context.getContentResolver().getType(uri);
        String format = LibraryStore.inferFormat(fileName, mime);
        String fallbackTitle = stripExtension(fileName);
        File cacheRoot = new File(context.getCacheDir(), "reader_books/" + Integer.toHexString(uri.toString().hashCode()));
        if (!cacheRoot.exists() && !cacheRoot.mkdirs()) throw new IOException("Не удалось создать кэш книги");

        switch (format) {
            case "EPUB": {
                File epub = new File(cacheRoot, "book.epub");
                if (!epub.isFile() || epub.length() == 0) {
                    copyToFile(open(context, uri), epub);
                }
                return EpubParser.parse(epub, new File(cacheRoot, "epub"), fallbackTitle);
            }
            case "FB2": {
                try (InputStream input = open(context, uri)) {
                    return Fb2Parser.parse(new ByteArrayInputStream(HtmlUtil.readAll(input)), new File(cacheRoot, "fb2"), fallbackTitle);
                }
            }
            case "FB2.ZIP":
            case "ZIP": {
                try (ZipInputStream zip = new ZipInputStream(open(context, uri))) {
                    ZipEntry entry;
                    int entries = 0;
                    while ((entry = zip.getNextEntry()) != null) {
                        if (++entries > 1000) throw new IOException("Слишком много файлов внутри ZIP");
                        if (!entry.isDirectory() && entry.getName().toLowerCase().endsWith(".fb2")) {
                            byte[] fb2 = HtmlUtil.readAll(zip);
                            return Fb2Parser.parse(new ByteArrayInputStream(fb2), new File(cacheRoot, "fb2"), stripExtension(new File(entry.getName()).getName()));
                        }
                    }
                }
                throw new IOException("В ZIP-архиве не найден файл FB2");
            }
            case "HTML": {
                try (InputStream input = open(context, uri)) {
                    String raw = HtmlUtil.decodeText(HtmlUtil.readAll(input));
                    String body = HtmlUtil.stripDangerousHtml(HtmlUtil.bodyOf(raw));
                    String title = extractHtmlTitle(raw, fallbackTitle);
                    return new ReaderDocument(title, "", HtmlUtil.wrap(title, "", body), "about:blank");
                }
            }
            case "TXT": {
                try (InputStream input = open(context, uri)) {
                    return TextParser.parse(input, fallbackTitle);
                }
            }
            default:
                throw new IOException("Формат " + format + " пока не поддерживается");
        }
    }

    private static InputStream open(Context context, Uri uri) throws IOException {
        InputStream input = context.getContentResolver().openInputStream(uri);
        if (input == null) throw new IOException("Не удалось открыть файл");
        return input;
    }

    private static void copyToFile(InputStream input, File target) throws IOException {
        try (InputStream source = input; FileOutputStream output = new FileOutputStream(target)) {
            byte[] buffer = new byte[16384];
            long total = 0;
            int read;
            while ((read = source.read(buffer)) != -1) {
                total += read;
                if (total > 256L * 1024L * 1024L) throw new IOException("Файл слишком большой");
                output.write(buffer, 0, read);
            }
        }
    }

    private static String resolveName(Context context, Uri uri) {
        ContentResolver resolver = context.getContentResolver();
        try (Cursor cursor = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String value = cursor.getString(index);
                    if (value != null && !value.trim().isEmpty()) return value;
                }
            }
        } catch (Exception ignored) {
        }
        String last = uri.getLastPathSegment();
        return last == null ? "Книга" : last;
    }

    private static String stripExtension(String name) {
        if (name == null) return "Книга";
        return name.replaceFirst("(?i)\\.fb2\\.zip$", "")
                .replaceFirst("(?i)\\.(epub|fb2|txt|html?|zip)$", "")
                .replace('_', ' ').trim();
    }

    private static String extractHtmlTitle(String html, String fallback) {
        java.util.regex.Matcher matcher = java.util.regex.Pattern
                .compile("(?is)<title[^>]*>(.*?)</title\\s*>").matcher(html);
        if (matcher.find()) {
            String title = HtmlUtil.cleanTitle(matcher.group(1));
            if (!title.isEmpty()) return title;
        }
        return fallback;
    }
}
