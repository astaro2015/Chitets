#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")" && pwd)"
sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$sdk_root" || ! -d "$sdk_root" ]]; then
  echo "Android SDK not found. Set ANDROID_SDK_ROOT or ANDROID_HOME." >&2
  exit 1
fi
if ! command -v javac >/dev/null 2>&1 || ! javac -version 2>&1 | grep -Eq 'javac (1[7-9]|[2-9][0-9])'; then
  echo "JDK 17+ is required." >&2
  exit 1
fi

build_tools="$sdk_root/build-tools/35.0.0"
platform_jar="$sdk_root/platforms/android-35/android.jar"
if [[ ! -d "$build_tools" || ! -f "$platform_jar" ]]; then
  echo "Android API 35 and Build Tools 35.0.0 are required." >&2
  exit 1
fi

tools="$project_dir/.build-tools"
deps="$tools/deps"
out="$project_dir/manual-build"
dist="$project_dir/dist"
mkdir -p "$deps" "$dist"

fetch_jar() {
  local url="$1" file="$2" min="$3"
  if [[ -f "$file" && $(stat -c%s "$file") -ge $min ]] && jar tf "$file" >/dev/null 2>&1; then return; fi
  echo "Downloading $(basename "$file")..."
  curl -fL --retry 5 --retry-delay 2 -o "$file" "$url"
  jar tf "$file" >/dev/null
}
fetch_jar "https://repo.maven.apache.org/maven2/com/github/junrar/junrar/8.1.0/junrar-8.1.0.jar" "$deps/junrar-8.1.0.jar" 200000
fetch_jar "https://repo.maven.apache.org/maven2/org/slf4j/slf4j-api/2.0.17/slf4j-api-2.0.17.jar" "$deps/slf4j-api-2.0.17.jar" 50000

rm -rf "$out"
mkdir -p "$out/compiled" "$out/gen" "$out/classes" "$out/dex"

"$build_tools/aapt2" compile --dir "$project_dir/app/src/main/res" -o "$out/compiled"
mapfile -t flat_files < <(find "$out/compiled" -name '*.flat' -type f | sort)
[[ ${#flat_files[@]} -gt 0 ]] || { echo "aapt2 produced no .flat files" >&2; exit 1; }
link_args=(link -o "$out/resources.apk" -I "$platform_jar" --manifest "$project_dir/app/src/main/AndroidManifest.xml" --java "$out/gen" --min-sdk-version 26 --target-sdk-version 35 --version-code 4 --version-name 0.4.0 --auto-add-overlay)
for f in "${flat_files[@]}"; do link_args+=(-R "$f"); done
"$build_tools/aapt2" "${link_args[@]}"

find "$project_dir/app/src/main/java" "$out/gen" -name '*.java' -print | sort > "$out/sources.txt"
cp="$platform_jar:$deps/junrar-8.1.0.jar:$deps/slf4j-api-2.0.17.jar"
javac -encoding UTF-8 -source 17 -target 17 -classpath "$cp" -d "$out/classes" "@$out/sources.txt"
jar cf "$out/classes.jar" -C "$out/classes" .
"$build_tools/d8" --release --min-api 26 --lib "$platform_jar" --output "$out/dex" "$out/classes.jar" "$deps/junrar-8.1.0.jar" "$deps/slf4j-api-2.0.17.jar"

cp "$out/resources.apk" "$out/with-dex.apk"
for dex in "$out"/dex/classes*.dex; do jar uf "$out/with-dex.apk" -C "$out/dex" "$(basename "$dex")"; done
"$build_tools/zipalign" -f 4 "$out/with-dex.apk" "$out/aligned.apk"

keystore="$tools/chitets-debug.keystore"
if [[ ! -f "$keystore" ]]; then
  keytool -genkeypair -keystore "$keystore" -storepass android -alias androiddebugkey -keypass android \
    -dname "CN=Android Debug,O=Chitets,C=RU" -keyalg RSA -keysize 2048 -validity 10000 >/dev/null 2>&1
fi
apk="$dist/Chitets-0.4.0-debug.apk"
"$build_tools/apksigner" sign --ks "$keystore" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$apk" "$out/aligned.apk"
"$build_tools/apksigner" verify --verbose "$apk"
echo "APK: $apk"
