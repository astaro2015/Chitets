# Changelog

## 0.4.0

- CBZ/CBR comic reader with natural page ordering, zoom, swipes, manga direction and night inversion.
- Advanced PDF mode: crop margins, night inversion, two-page spreads and retained zoom.
- EPUB local CSS preservation and embedded-font support.
- Real page X/Y metrics for WebView paged mode.
- JSON backup/import for library, reading state, bookmarks, notes, collections and UI settings.
- Junrar 8.1.0 / SLF4J build integration in Gradle and one-click builders.
- Multi-dex packaging in the Windows/Linux manual build scripts.
- Fixed duplicate `onTouchEvent` declaration in the previous PDF viewer source.

## 0.3.0

- Notes/quotes, improved search, edge gestures, reading-time estimation.
- Folder import, collections and series metadata.
- Anchor-based reading position restoration.

## 0.2.0

- Covers, TOC, bookmarks, fullscreen reading, progress seek and library improvements.
